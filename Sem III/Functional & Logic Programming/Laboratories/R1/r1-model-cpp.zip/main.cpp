#include "lista.h"
#include <iostream>

int main()
{
   Lista l;
   l=creare();
   tipar(l);
}
