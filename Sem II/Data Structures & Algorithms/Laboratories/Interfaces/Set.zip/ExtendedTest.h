#pragma once

void testAllExtended();

