#include "Stack.h"
#include "ShortTest.h"
#include "ExtendedTest.h"
#include <iostream>

using namespace std;

int main() {
	//testAll();
	//testAllExtended();
	cout << "That's all" << endl;
	system("pause");
}