#include "MultiMapIterator.h"
#include "MultiMap.h"


MultiMapIterator::MultiMapIterator(const MultiMap& c): col(c) {
	//TODO - Implementation
}

TElem MultiMapIterator::getCurrent() const{
	//TODO - Implementation
	return NULL_TELEM;
}

bool MultiMapIterator::valid() const {
	//TODO - Implementation
	return false;
}

void MultiMapIterator::next() {
	//TODO - Implementation
}

void MultiMapIterator::first() {
	//TODO - Implementation
}

