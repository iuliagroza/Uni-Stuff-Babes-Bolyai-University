#include <stdio.h>

int main() {
    printf("asdf asdf sadf asdf asdf asdf asdf asdf asfd\n");
    return 0;
}
